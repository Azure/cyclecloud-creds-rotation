This package installs a credential-rotation command into an existing CycleCloud installation.

Run install.sh to install. 
