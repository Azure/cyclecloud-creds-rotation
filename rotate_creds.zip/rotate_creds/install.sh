#!/bin/bash

# Copyright (c) Microsoft, 2021
# All rights reserved

# This installs the credential-rotation command line to update the credentials stored in cluster nodes.
# Optional arguments:
# --installdir: the location of the CycleCloud server if not /opt/cycle_server
# --force: if given, overwrites even if this appears to be in the install already
# --norestart: does not restart CycleCloud. Note that not all features may work without a restart.

set -e

CS_HOME="/opt/cycle_server"

INSTALL_DIR=/opt/cycle_server
FORCE=false
RESTART=true

while (( "$#" )); do
    var=$1
    shift
    if [ "$var" == "--installdir" ]; then
        INSTALL_DIR=$1
        shift
    elif [ "$var" == "--force" ]; then
        FORCE=true
    elif [ "$var" == "--norestart" ]; then
        RESTART=false
    fi
done


if [ -f "$INSTALL_DIR/util/rotate_creds.sh" -a "$FORCE" == "false" ]; then
    echo "Package already installed in CycleCloud. Use --force to install anyway."
    exit 1
fi

if [ $(uname -s) == Darwin ]; then
    # Mac
    owner=$(stat -f %Su "$INSTALL_DIR/cycle_server")
    group=$(stat -f %Sg "$INSTALL_DIR/cycle_server")
else
    # Linux
    owner=$(stat -c %U "$INSTALL_DIR/cycle_server")
    group=$(stat -c %G "$INSTALL_DIR/cycle_server")
fi

chown -R $owner:$group files

chmod 550 files/util/* files/system/scripts/*
chmod 700 files/system/etc/*
cp -p -f files/system/scripts/* "$INSTALL_DIR/system/scripts"
cp -p -f files/system/etc/* "$INSTALL_DIR/system/etc"
cp -p -f files/util/* "$INSTALL_DIR/util"

# include the specific version in the distribution
version=$(cat "$INSTALL_DIR/system/version")
query="update application.setting set Value=\"marketplace:$version\" where Name == \"distribution_method\" && Value == \"marketplace\" "
"$INSTALL_DIR/cycle_server" execute "$query" > /dev/null

if [ "$RESTART" == "true" ]; then
    echo "Restarting..."
    "$INSTALL_DIR/cycle_server" restart
    "$INSTALL_DIR/cycle_server" await_startup
fi

echo "CycleCloud was updated successfully."
