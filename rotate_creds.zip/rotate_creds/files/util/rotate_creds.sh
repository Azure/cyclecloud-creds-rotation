#!/bin/bash

`dirname $0`/../system/scripts/rotate_creds.sh "$@"