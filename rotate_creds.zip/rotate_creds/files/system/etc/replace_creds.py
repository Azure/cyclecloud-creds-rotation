# Copyright 2021 Microsoft. All Rights Reserved
 
from __future__ import print_function

import argparse
import shutil
import os, stat
import fnmatch
import subprocess
import sys
try:
    import configparser
except ImportError:
    import ConfigParser as configparser

# Replaces the CycleCloud cluster-access password and cyclecloud public key with new values.
# Usage: replace_creds.py --new-password NEW_PASSWORD --pubkey OLD_PUBKEY NEW_PUBKEY

is_windows = os.name == 'nt'
if is_windows:
    import win32file, win32security

# this covers /opt/cycle/jetpack as well as the newer scheduler integrations that go in /opt/cycle
root_password_dir = "c:/cycle" if is_windows else "/opt/cycle"
password_file_patterns = ["*.ini", "*.json", "*.sh"]

config_file = os.path.join(root_password_dir, "jetpack/config/jetpack.ini")
ssh_authorized_file = None if is_windows else os.path.expanduser("~cyclecloud/.ssh/authorized_keys") 

jetpack_cmd = "c:/cycle/jetpack/bin/jetpack.cmd" if is_windows else "/opt/cycle/jetpack/bin/jetpack"

# we enforce a min here since we are doing a simple text replacement on the files
# and don't want to encode strings that would match non-password text
min_password_length = 8

def copy_ownership(source, dest):
    if is_windows:
        for p in [win32security.OWNER_SECURITY_INFORMATION, win32security.GROUP_SECURITY_INFORMATION]:
            sd = win32security.GetFileSecurity(source, p)
            win32security.SetFileSecurity(dest, p, sd)
    else:
        st = os.stat(source)
        os.chown(dest, st[stat.ST_UID], st[stat.ST_GID])


def write_file(filename, contents):
    with open(filename + ".__tmp__", mode='w') as tmp_file:
        tmp_file.write(contents)

    shutil.copystat(filename, tmp_file.name)
    copy_ownership(filename, tmp_file.name)
    shutil.move(tmp_file.name, filename)


def replace_in_file(filename, input, output):
    '''Replaces the input string with the output if it exists'''
    replaced = False
    with open(filename) as src_file:
        contents = src_file.read()
        if contents.find(input) != -1:
            if contents.find(output) != -1:
                # if both strings exist, then replacing the input with the output means 
                # we will not be able to "reverse" this accurately so it is probably not a proper replacement. 
                # In practice this means that the output value is not a password, or at least not unique enough to serve as one.
                raise ValueError("Cannot replace %s with %s: both strings exist in %s already" % (input, output, filename))

            write_file(filename, contents.replace(input, output))
            replaced = True

    return replaced

def replace_in_files(root_dir, patterns, input, output):
    '''Walks the tree and replaces the input string with the output in every file that matches a glob in patterns'''
    replaced_count = 0
    for root, dirs, files in os.walk(root_dir):
        for pattern in patterns:
            for item in fnmatch.filter(files, pattern):
                filename = os.path.join(root, item)
                # note: we leave jetpack.ini for last
                if filename != config_file:
                    replaced = replace_in_file(filename, input, output)
                    if replaced:
                        replaced_count += 1

    return replaced_count

def main():
    parser = argparse.ArgumentParser(description='Replaces the credentials on this machine used to access CycleCloud and the public key for the cyclecloud user')
    parser.add_argument('--password', metavar='PASSWORD', dest='new_password', required=True,
                        help='The new password to use')
    parser.add_argument('--old-password', metavar='PASSWORD', dest='old_password', required=False,
                        help='The old password to replace (normally determined automatically)')
    parser.add_argument('--pubkey', metavar='PUBKEY', dest='pubkey', nargs=2, required=False,
                        help='The old and new public key')

    args = parser.parse_args()

    if len(args.new_password) < min_password_length:
        raise ValueError("Cannot use a new password less than %d characters long" % min_password_length)

    if args.old_password:
        if len(args.old_password) < min_password_length:
            raise ValueError("Cannot replace a password string less than %d characters long" % min_password_length)
        old_password = args.old_password
    else:
        config = configparser.RawConfigParser()
        config.read(config_file)
        old_password = config.get("cycle_server", "api_password")
        if not old_password:
            raise ValueError("Cannot determine password from %s" % config_file)

    replaced_count = 0
    if old_password != args.new_password:
        # replace passwords (only if different)
        replaced_count += replace_in_files(root_password_dir, password_file_patterns, old_password, args.new_password)

        # replace the jetpack.ini file last, because this "throws away" the old password we use for the next run.
        # if the script is terminated before this point, we can still resume from jetpack.ini and continue.
        replaced_count += replace_in_file(config_file, old_password, args.new_password)

    replaced_pub_key = False
    if args.pubkey and ssh_authorized_file:
        # replace public key on linux
        replaced_pub_key = replace_in_file(ssh_authorized_file, args.pubkey[0], args.pubkey[1])
        if not replaced_pub_key:
            with open(ssh_authorized_file) as src_file:
                contents = src_file.read().strip()
                contents += "\n" + args.pubkey[1]
                write_file(ssh_authorized_file, contents)
                replaced_pub_key = True

    message = "Replaced password in %d files" % replaced_count
    if replaced_pub_key:
        message += " and public key in %s" % ssh_authorized_file
    print(message)
    subprocess.check_call([jetpack_cmd, "log", message])

try:
    main()
except ValueError as e:
    print("ERROR: %s" % e)
