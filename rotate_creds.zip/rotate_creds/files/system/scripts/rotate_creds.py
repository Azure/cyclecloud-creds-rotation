# Copyright 2021 Microsoft. All Rights Reserved

from __future__ import print_function

import argparse
import subprocess
import shutil
import os, stat
from pwd import getpwuid
import json
import random
import string
import pipes, shlex
import logging
import threading
import time, datetime
import sys
import traceback
import hashlib, base64
import Queue as queue

# Replaces the password and public key on all nodes in all clusters with a new password/public key.
# Windows nodes are not modified. This script can be resumed.
parser = argparse.ArgumentParser(description='Replaces the CycleCloud password and cyclecloud SSH key on all nodes in this CycleCloud install')
parser.add_argument('--force', dest='force', action="store_true", required=False,
                    help='If given, the script will not request confirmation before rotating the password')
parser.add_argument('--force-rotate', dest='force_rotate', action="store_true", required=False,
                    help='If given, ignores any in-progress rotation and starts over with new credentials')
parser.add_argument('--no-test', dest='no_test', action="store_true", required=False,
                    help='If given, does not attempt to test SSH connectivity first')
parser.add_argument('--ssh-identity', metavar='SSH_IDENTITY', dest='ssh_identity', required=False,
                    help='The path to a key to use to connect to the nodes to run the script, if not the default')
parser.add_argument('--ssh-username', metavar='SSH_USERNAME', dest='ssh_username', required=False,
                    help='The username to ssh as, if not cyclecloud. Note this user must have sudo permission!')

thread_count = 20

# some OSes don't have a "python", only "python3", so we just use the built-in one (either 2 or 3 depending on the jetpack version)
jetpack_python = "/opt/cycle/jetpack/system/embedded/bin/python"
jetpack_python_win = "c:\cycle\jetpack\system\embedded\python\python"


def write_file(filename, contents):
    with open(filename + ".__tmp__", mode='w') as tmp_file:
        tmp_file.write(contents)
    move_file(tmp_file.name, filename)

def move_file(source, dest):
    # make dest look like source
    shutil.copystat(dest, source)
    st = os.stat(dest)
    os.chown(source, st[stat.ST_UID], st[stat.ST_GID])
    # then move source over dest
    shutil.move(source, dest)

def random_password():
    rng = random.SystemRandom()
    
    def choice(choices):
        return choices[rng.randint(0, len(choices)-1)]
    
    def insert_char(str, char):
        idx = rng.randint(1, len(str)-2)
        return str[:idx] + char + str[idx:]
    
    if hasattr(string, "letters"):
        letters = string.letters
    else:
        letters = string.ascii_letters

    pw = "".join([choice(letters + string.digits) for i in range(12)])
    # include punctuation in the middle
    pw = insert_char(pw, choice("-_."))
    
    return pw

class Options:
    def __init__(self, installation, username):
        self.installation = installation
        self.username = username

def get_ssh_options(host, options):
    # connect with both the old key and the new key
    ssh_keys = ["-i", ssh_file]
    if os.path.exists(old_ssh_file):
        ssh_keys.extend(["-i", old_ssh_file])
    if args.ssh_identity:
        ssh_keys.extend(["-i", args.ssh_identity])

    ssh_options = shlex.split("-o ConnectTimeout=15 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR")
    return_proxy = cluster_return_proxies.get(host["ClusterName"])
    if return_proxy and not host.get("IsReturnProxy"):
        # nodes in a cluster with a return proxy connect through the proxy's IP
        proxy_options = []
        proxy_options.extend(ssh_options)
        proxy_options.extend(ssh_keys)
        proxy_command = 'ProxyCommand=/usr/bin/ssh %s -W %%h:%%p %s@%s' % (" ".join(proxy_options), return_proxy["Username"], return_proxy["Ip"])
        ssh_options.append("-o")
        ssh_options.append(proxy_command)

    ssh_options.extend(ssh_keys)

    return ssh_options

class CommandError(Exception):
    pass

def quote_command(command_args):
    return " ".join([pipes.quote(a) for a in command_args])

def run_command(command_args, purpose):
    try:
        if isinstance(command_args, str):
            command_args = shlex.split(command_args)
        command = quote_command(command_args)
        output = subprocess.check_output(command_args, stderr=subprocess.STDOUT)
        return output.decode("utf-8")
    except subprocess.CalledProcessError as e:
        output = e.output.decode("utf-8")
        if output.find("Permission denied (publickey") != -1:
            message = "Failed to %s: %s" % (purpose, output.strip())
        else:
            output = "\n      ".join(output.split("\n")).strip()
            message = "Failed to %s\n    Command: %s\n    Output from command:\n      %s" % (purpose, command, output)
        raise CommandError(message)

def update_node(host, options, mapping):
    ip = get_ip_address(host)

    ssh_options = get_ssh_options(host, options)
    scp_command = ["scp"]
    scp_command.extend(ssh_options)
    scp_command.extend(["%s/system/etc/replace_creds.py" % options.installation, "%s@%s:/tmp/replace_creds.py" % (options.username, ip)])
    run_command(scp_command, "copy rotate_creds.py to node")

    ssh_command = ["ssh"]
    ssh_command.extend(ssh_options)
    ssh_command.append("%s@%s" % (options.username, ip))
    ssh_command.append("sudo %s /tmp/replace_creds.py --password '%s' --pubkey '%s' '%s'" % 
        (jetpack_python, mapping["new_password"], mapping["old_public_key"], mapping["new_public_key"]))
    output = run_command(ssh_command, "rotate credentials")
    return output.strip()

def test_ssh(host, options):
    ssh_command = ["ssh"]
    ssh_command.extend(get_ssh_options(host, options))
    ssh_command.append("%s@%s" % (options.username, get_ip_address(host)))
    ssh_command.append("sudo whoami")
    output = run_command(ssh_command, "connect via ssh")
    return output.strip()

def run_query(query, options):
    result = json.loads(subprocess.check_output([options.installation + "/cycle_server", "execute", "-format", "json", query]))
    return result

def run_execute(execute, options):
    subprocess.check_output([options.installation + "/cycle_server", "execute", execute])

def update_password(new_password):
    encoded = base64.b64encode(new_password.encode("utf-8")).decode("utf-8")
    store = 'store [AdType="AuthenticatedUser"; Name="cyclecloud_access"; Key=blob("%s"); RawPassword="%s"]' % (encoded, new_password)
    run_execute(store, options)

def format_host(host):
    ip_address = get_ip_address(host)
    return_proxy = cluster_return_proxies.get(host["ClusterName"])
    if return_proxy and not host.get("IsReturnProxy"):
        ip_address = "%s -> %s" % (return_proxy["Ip"], ip_address)

    return 'node %s/%s (%s)' % (host["ClusterName"], host["Name"], ip_address or "--")

def get_ip_address(host):
    return host.get("PublicIp") or host.get("PrivateIp")

def hash_value(value):
    h = hashlib.sha512()
    # simple salt
    h.update("727d86de".encode("utf-8"))
    h.update(value.encode("utf-8"))
    return h.hexdigest()

def run_on_threads(work_items, handler, output_callback, tc=thread_count):
    '''Runs the given handler on a set of items on many threads and runs the callback on this thread with each result'''
    work_queue = queue.Queue()
    result_queue = queue.Queue()
    for work_item in work_items:
        work_queue.put(work_item)

    def run_thread(thread_index, work_queue, result_queue, handler):
        while not work_queue.empty():
            work_item = work_queue.get()
            if work_item is None:
                break
            try:
                output = handler(work_item)
                result_queue.put((work_item, True, output))
            except Exception as e:
                result_queue.put((work_item, False, e))

    # start the threads
    threads = []
    for index in range(thread_count):
        x = threading.Thread(target=run_thread, args=(index, work_queue, result_queue, handler))
        threads.append(x)
        x.start()
        # add in a "poison pill" per thread so each thread shuts down
        work_queue.put(None)

    def wait_for_threads(threads, result_queue):
        '''Waits on all the threads to exit and then signals with None to the result queue'''
        for index, thread in enumerate(threads):
            thread.join()
        result_queue.put(None)

    x = threading.Thread(target=wait_for_threads, args=(threads, result_queue))
    x.start()

    while True:
        result = result_queue.get()
        if result is None:
            # all threads are done and we processed all results
            break
        output_callback(result[0], result[1], result[2])


args = parser.parse_args()

installation = os.getenv("CS_HOME")
installation = os.path.abspath(installation)
username = args.ssh_username or "cyclecloud"

options = Options(installation, username)

logging.basicConfig(filename=installation + "/logs/credential_rotation.log", format='%(asctime)s %(message)s', level=logging.DEBUG)
console_handle = logging.StreamHandler()
console_handle.setLevel(logging.INFO)
logging.getLogger().addHandler(console_handle)

status_file = os.path.join(installation, "config/var/rotate_creds.json")

cycle_server_owner = getpwuid(os.stat(os.path.join(installation, "cycle_server")).st_uid).pw_name
ssh_file = os.path.expanduser("~%s/.ssh/cyclecloud.pem" % cycle_server_owner)
old_ssh_file = ssh_file + ".old"

resume_rotation = False
if os.path.exists(status_file):
    if args.force_rotate:
        # ignore this file
        os.remove(status_file)
    else:
        print("Resuming from existing in-progress rotation (use --force-rotate to ignore the in-progress operation)")

if os.path.exists(status_file):
    resume_rotation = True
    with open(status_file, "r") as f:
        status = json.load(f)
else:
    status = {}
    status["hosts"] = {}
    with open(status_file, "w") as f:
        f.write(json.dumps(status, indent=True))

invalid_host_list = False

users = run_query('select * from AuthenticatedUser where name == "cyclecloud_access"', options)
current_password = None

if users:
    if resume_rotation:
        current_password = base64.b64decode(users[0]["Key"]["$blob"]["data"]).decode("utf-8")
        hashed_password = hash_value(current_password)
        if hashed_password != status.get("password_hash"):
            status["password_hash"] = hashed_password
            invalid_host_list = True
else:
    raise ValueError("No cyclecloud_access user found")

# ssh-keygen is picky about this file and it was not always created with the right permissions
os.chmod(ssh_file, stat.S_IRUSR | stat.S_IWUSR)

current_public_key = run_command(["ssh-keygen", "-y", "-f", ssh_file], "Get current SSH public key").strip()
if resume_rotation:
    hashed_public_key = hash_value(current_public_key)
    if hashed_public_key != status.get("public_key_hash"):
        status["public_key_hash"] = hashed_public_key
        invalid_host_list = True

if invalid_host_list:
    # if the password/pubkey does not match the value in the file being resumed from, 
    # the list of hosts that were updated is irrelevant
    status["hosts"] = {}
    write_file(status_file, json.dumps(status, indent=True))

query = '''select InstanceId, ClusterName, Name, State, StatusMessage, IsReturnProxy, I.PrivateIp as PrivateIp, I.PublicIp as PublicIp, I.ScaleSetName isnt undefined as IsScaleset, 
I.OperatingSystem as OperatingSystem, S.SinglePlacementGroup === true as SinglePlacementGroup from Cloud.Node
 outer join Azure.Instance I on InstanceId === I.InstanceId outer join Azure.ComputeCell S on Cell === S.Name 
 where IsArray !== true && TargetState == "Started" order by I.OperatingSystem, I.PrivateIp'''
hosts = run_query(query, options)

cluster_return_proxies = {}
has_spg_nodes = False
hosts_to_update = []
windows_hosts = []
already_updated_hosts = []
starting_hosts = []

for host in hosts:
    not_started = False
    update_host = False
    if host["OperatingSystem"] != "windows":
        instance_id = host["InstanceId"]
        if instance_id:
            existing_host = status["hosts"].get(instance_id, {})
            if not existing_host.get("Succeeded"):
                update_host = True
        else:
            not_started = True
    else:
        windows_hosts.append(host)

    if host["SinglePlacementGroup"]:
        has_spg_nodes = True
    if not (host["State"].lower() in ["started", "installation", "configuration"]):
        not_started = True

    if update_host:
        hosts_to_update.append(host)

    if not_started:
        starting_hosts.append(host)
    
    if host.get("IsReturnProxy") and host.get("PublicIp"):
        # have to connect through the public IP
        cluster_return_proxies[host["ClusterName"]] = {"Ip": host.get("PublicIp"), "Username": options.username}


if has_spg_nodes:
    print("\nError: some of these nodes are in placement groups and must be terminated before credentials can be rotated.")
    logging.debug("Failed to rotate credentials: nodes in a placement group (MPI) are not supported")
    sys.exit(1)

if starting_hosts:
    print("\nThese nodes are not fully started yet:")
    for host in starting_hosts:
        print("  %s: %s" % (format_host(host), host["StatusMessage"] or "starting"))
    logging.debug("Failed to rotate credentials: some nodes are starting")
    print("\nError: rotating credentials cannot be done until the above nodes finish starting.")
    sys.exit(1)

reachable_hosts = []
unreachable_hosts = []

def process_test_result(item, success, output):
    host, options = item
    if success and output == "root":
        reachable_hosts.append(host)
    else:
        unreachable_hosts.append(host)
        logging.debug("Failed to connect to %s", format_host(host))
        print("  %s: %s" % (format_host(host), str(output)))

if not args.force:
    if hosts_to_update and not args.no_test:
        print("Testing SSH connectivity to %d of the %d total node(s) that need to have credentials rotated..." % (len(hosts_to_update), len(hosts)))

        commands_to_run = [(host, options) for host in hosts_to_update]
        run_on_threads(commands_to_run, lambda i: test_ssh(*i), process_test_result)

        hosts_to_update = reachable_hosts
        
    print("There are %d total node(s) that need to have credentials rotated:" % len(hosts))

    if not status.get("Rotated"):
        if reachable_hosts or unreachable_hosts or windows_hosts:
            if not args.no_test:
                if reachable_hosts:
                    print("  %d of these node(s) could be reached via SSH and will be updated automatically." % len(reachable_hosts))
                if unreachable_hosts:
                    print("  %d of these node(s) are NOT responding to SSH and CANNOT be updated automatically." % len(unreachable_hosts))
            else:
                if hosts_to_update:
                    print("  %d of these node(s) were not tested for SSH and may not be able to be updated automatically." % len(hosts_to_update))
            if windows_hosts:
                print("  %d of these node(s) are running Windows and cannot be updated automatically." % len(windows_hosts))
            print("")

        print("This script will make the following changes:")
        print("  - Rotate the password that nodes used to connect back to CycleCloud")
        print("  - Rotate the SSH key that CycleCloud uses to SSH in to nodes for the return proxy")
        print("  - SSH to all Linux nodes and change the above credentials on each")
        manual_updates = args.no_test or (unreachable_hosts or windows_hosts)
        if manual_updates:
            print("\nWARNING:")
            print("  Windows nodes, as well as Linux nodes that are not reachable by SSH, will need to be updated manually.")
        confirmed = raw_input("Do you want to rotate the credentials now? [y/N] ")
        if confirmed != "y":
            sys.exit(1)

if not status.get("Rotated"):
    # generate a new password
    current_password = random_password()
    update_password(current_password)
    hashed_password = hash_value(current_password)
    status["password_hash"] = hashed_password

    # generate a new public key
    new_ssh_file = ssh_file + ".new"
    new_ssh_pub_file = ssh_file + ".new.pub"
    # ssh-keygen prompts about overwriting the files, if they exist
    if os.path.exists(new_ssh_file):
        os.remove(new_ssh_file)
    if os.path.exists(new_ssh_pub_file):
        os.remove(new_ssh_pub_file)

    run_command(["ssh-keygen", "-b", "4096", "-m", "pem", "-t", "rsa", "-N", "", "-q", "-C", "cyclecloud_access", "-f", new_ssh_file], "Create a new SSH key")
    # move this after the command in case the command fails
    if os.path.exists(ssh_file):
        shutil.copy(ssh_file, old_ssh_file)
    shutil.move(new_ssh_file, ssh_file)
    # ssh-keygen always creates the public file too
    os.remove(new_ssh_pub_file)

    current_public_key = run_command(["ssh-keygen", "-y", "-f", ssh_file], "Get current SSH public key").strip()
    status["public_key_hash"] = hash_value(current_public_key)

    status["Rotated"] = True
    write_file(status_file, json.dumps(status, indent=True))

old_public_key = run_command(["ssh-keygen", "-y", "-f", old_ssh_file], "Get old SSH public key").strip()

mapping = {"new_password": current_password, "new_public_key": current_public_key, "old_public_key": old_public_key}

short_password = current_password[0:4]
short_public_key = current_public_key.split(" ")[1][-8:]
message = "Will resume rotating" if resume_rotation else "Rotating"
logging.info("%s password to %s... and public key to ...%s", message, short_password, short_public_key)

for host in already_updated_hosts:
    print("  %s: already rotated" % format_host(host))
    logging.debug("%s was already rotated", format_host(host))

failed_hosts_responses = []
success_logged = False

def process_update_result(item, success, output):
    global success_logged
    host, options, mapping = item
    instance_id = host["InstanceId"]
    existing_host = status["hosts"].get(instance_id, {})

    if success:
        if not success_logged:
            print("\nThese nodes were updated successfully:")
            success_logged = True
        print("  %s: %s" % (format_host(host), output))
        logging.debug("Successfully rotated credentials on %s", format_host(host))

        existing_host["Succeeded"] = True
        status["hosts"][instance_id] = existing_host
    else:
        failed_hosts_responses.append((host, output))

    # update this with every host, in case the user aborts in the middle
    write_file(status_file, json.dumps(status, indent=True))

commands_to_run = [(host, options, mapping) for host in hosts_to_update]
run_on_threads(commands_to_run, lambda i: update_node(*i), process_update_result)

# flag the scalesets as unavailable so they do not get used for new nodes
# (this cannot work for single-placement-group nodes which is why those are blocked)
run_execute('update Azure.ComputeCell set Available=false', options)

complete = True

if unreachable_hosts or windows_hosts or failed_hosts_responses:
    complete = False
    print("\nThese nodes must be updated manually:")
    for host in windows_hosts:
        print("  %s: is running Windows" % format_host(host))
        logging.debug("%s is running Windows", format_host(host))
    for host in unreachable_hosts:
        print("  %s: could not be reached via SSH" % format_host(host))
        logging.debug("%s could not be reached via SSH", format_host(host))
    for (host, output) in failed_hosts_responses:
        print("  %s: %s" % (format_host(host), str(output)))
        logging.debug("Failed to rotate credentials on %s:\n%s", format_host(host), str(output))

    script_path = os.path.join(options.installation, "system/etc/replace_creds.py")

    print("\nCopy %s to each node and and log in. \nNote that the old SSH key is located in %s." % (script_path, old_ssh_file))
    print("Then run the following command: ")
    command = "replace_creds.py --password %s --pubkey '%s' '%s'" % (mapping["new_password"], mapping["old_public_key"], mapping["new_public_key"])
    print("  sudo %s %s" % (jetpack_python, command))
    if windows_hosts:
        print("\nFor Windows nodes, run this command in an Administrator console:")
        command = "replace_creds.py --password %s" % mapping["new_password"]
        print("  %s %s" % (jetpack_python_win, command))

    if unreachable_hosts or failed_hosts_responses:
        retry_args = [os.path.join(installation, "util/rotate_creds.sh")]
        retry_args.extend(sys.argv[1:])
        print("\nYou can also retry the above failures with the following command:\n  %s" % quote_command(retry_args))

if complete:
    print("All nodes rotated")
    os.remove(status_file)
    if os.path.exists(old_ssh_file):
        os.remove(old_ssh_file)
