#!/bin/bash

SCRIPTS_DIR=$(dirname "$0")
export CS_HOME=$("$SCRIPTS_DIR/get_home.sh")

source "$SCRIPTS_DIR/exec_util.sh" "$SCRIPTS_DIR"
if [ $? -ne 0 ]; then
    echo "Initialization error"
    exit 1
fi

run_script do_rotate_creds.sh "$@"

