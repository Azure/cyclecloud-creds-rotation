#!/bin/bash

SCRIPTS_DIR=$(dirname "$0")
export CS_HOME=$("$SCRIPTS_DIR/get_home.sh")

source "$SCRIPTS_DIR/exec_util.sh" "$SCRIPTS_DIR"
if [ $? -ne 0 ]; then
    exit 1
fi

"$CS_HOME/system/scripts/do_jython.sh" "$CS_HOME/system/scripts/rotate_creds.py" "$@"
val=$?
if [ $val -ne 0 ] ; then
    exit $val
fi
